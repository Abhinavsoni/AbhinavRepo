package pages.repo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;

public class AbhinavRepo extends UiBase {

    public void selectEmployee(String name) {
        List<WebElement> allEmployees= getDriver().findElements(By.cssSelector("tbody tr td:nth-of-type(1)"));
        boolean found=false;
        while(!found) {
            for (WebElement emp : allEmployees) {
                if (getDriver().findElement(By.cssSelector(emp.getTagName()+":nth-of-type(1)")).getAttribute("class").contains("jqx-tree-grid-expand-button ")) {
                    emp.click();
                    break;
                }
                else if(getDriver().findElement(By.cssSelector(emp.getTagName()+":nth-of-type(3)")).getText().contains(name)){
                    found=true;
                    break;
                }
            }
        }
    }
    
    public WebElement getSelectedData(){
        return getDriver().findElement(By.cssSelector("#btn"));
    }

    public List<String> resultTable(){
        List<String> result= new ArrayList<>();
        List<WebElement> results=  getDriver().findElements(By.cssSelector("listBoxContentlistBoxSelected>div>div"));
        for(WebElement e:results){ 
            result.add(e.getText()); 
        }
        return result;
    }

}
