package pages.actions;

import pages.repo.AbhinavRepo;

import java.util.List;

public class AbhinavUiActions extends AbhinavRepo {
    
    public void selectEmployeeName(List<String> employeeName){
        for(String s:employeeName){
            selectEmployee(s);
        }
    }

    public void verifyResult(List<String> employeeName) {
        getSelectedData().click();
        List<String> expectedResult=resultTable();
        assert(expectedResult.size()==employeeName.size());
        for(String s:employeeName){
            String locationOfEmployee=getLocation(s);
            String expectedText= s+" is from "+locationOfEmployee;
            assert (expectedResult.contains(expectedText));
        }
    }

    private String getLocation(String s) {
        //Hypohtetical Service
        //We can use any http client to get the data from this service
        return "";
    }
}
