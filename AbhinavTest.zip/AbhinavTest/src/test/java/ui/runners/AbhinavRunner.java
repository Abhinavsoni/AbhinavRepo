package ui.runners;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import ui.initializers.*;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;


//Custom test runner
@RunWith(Cucumber.class)
@CucumberOptions(
        features ="src/test/resources/featureFiles" ,
        glue = "classpath:ui.testSteps" ,
        tags="@employee",
        plugin = { "pretty","html:target/cucumber-reports","json:target/cucumber-reports/cucumber.json" },
        monochrome = true
)


public class AbhinavRunner {

    //Invoking browser
    @BeforeClass
    public static void setUpTest() {
        BrowserInitializer.initializeBrowser("firefox");
    }

    //Tearing down when the test completes
    @AfterClass
    public static void tearDown() {
        System.out.println("All tests Completed");
    }
}
