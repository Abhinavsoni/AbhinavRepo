package ui.initializers;

import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.BrowserType;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

//initializing the browser
public class BrowserInitializer {


    public static String getClient() {
        return client;
    }

    public static void setClient(String client) {
        BrowserInitializer.client = client;
    }

    private static String client;

    public static WebDriver initializeBrowser(String browser){
//To execute and test scripts in local comment line from 24 t0 30 and use the below commented snippet it will invoke the tests in local
            DesiredCapabilities capability = DesiredCapabilities.firefox();
            capability.setBrowserName("firefox");
            capability.setPlatform(Platform.ANY);
            return new FirefoxDriver(); }

    private static Capabilities getBrowserCapabilities(String browserType) {
        switch (browserType) {
            default:
                System.out.println("browser : " + browserType + " is invalid, Launching Firefox as browser of choice..");
            case "firefox":
                System.out.println("Opening firefox driver");
                FirefoxOptions fOptions = new FirefoxOptions();
                fOptions.setCapability(CapabilityType.BROWSER_NAME, BrowserType.FIREFOX);
                fOptions.setCapability(CapabilityType.PLATFORM_NAME, Platform.WINDOWS);
                fOptions.setBinary("C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe");
                return fOptions;
            case "chrome":
                System.out.println("Opening chrome driver");
                ChromeOptions cOptions = new ChromeOptions();
                cOptions.setCapability(CapabilityType.BROWSER_NAME, BrowserType.CHROME);
                cOptions.setCapability(CapabilityType.PLATFORM_NAME, Platform.WINDOWS);
                return cOptions;
            case "IE":
                System.out.println("Opening IE driver");
                return DesiredCapabilities.internetExplorer();

        }
    }
}
