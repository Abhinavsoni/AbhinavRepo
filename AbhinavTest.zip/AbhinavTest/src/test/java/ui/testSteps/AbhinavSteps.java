package ui.testSteps;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import gherkin.lexer.Th;
import pages.actions.AbhinavUiActions;


import java.util.Arrays;
import java.util.List;

public class AbhinavSteps {

    AbhinavUiActions abhinavUiActions = new AbhinavUiActions();

    @Given("^I select employee \"([^\"]*)\"$")
    public void selectEmoployee(String employeeName) throws Throwable {
        abhinavUiActions.selectEmployeeName(Arrays.asList(employeeName.split(",")));
    }

    @Then("^I verify the selected data for \"([^\"]*)\"$")
    public void verifySelectedValues(String employeeName) throws Throwable {
        abhinavUiActions.verifyResult(Arrays.asList(employeeName.split(",")));
    }


}